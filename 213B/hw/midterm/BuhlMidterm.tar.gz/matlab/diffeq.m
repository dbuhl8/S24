

function dy = diffeq(t, y)
    dy = [y(2);y(3);y(4);t^2];
end 
