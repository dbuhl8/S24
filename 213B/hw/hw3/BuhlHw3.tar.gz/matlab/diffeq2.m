

function dy = diffeq2(t, y)

 dy = [-y(1)+3*y(2)-5*y(3)+7*y(4);-2*y(2)+4*y(3)-6*y(4);-4*y(3)+6*y(4);-16*y(4)];
end
